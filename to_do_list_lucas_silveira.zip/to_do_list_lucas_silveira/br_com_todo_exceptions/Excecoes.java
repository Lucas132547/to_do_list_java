package to_do_list_lucas_silveira.br_com_todo_exceptions;

public class Excecoes {
    
}
